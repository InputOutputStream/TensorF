#include "Types/types.hpp"
#include "Operation.hpp"


#ifndef __Index_OPP_INCLUDED__
#define __Index_OPP_INCLUDED__


template <typename T>
class IndexOperation : public Operation<T>
{
    public:
    std::vector<Tensor_t<T>> inputs() const override { return {this->t1}; }
        Tensor_t<T> t1;
        Matrix<bool> mask;
        shape_t orig_shape;

    IndexOperation(Tensor_t<T> t1, const Matrix<bool>& inmask): t1(t1), mask(inmask){
    }
    void backward(Matrix<T> grad);

    Tensor_t<T> forward(); 

    void zero_grad();
    void reset_graph();
    void to_string(){
        std::cout << "Bool Index Operation \n";
    }
};


/**
 * Natural Index function Implementation
*/

    template <typename T>
    Tensor_t<T> IndexOperation<T>::forward()
    {
        this->orig_shape = this->t1->val.shape;
        return std::make_shared<Tensor<T>>(
            this->t1->val.at(mask), this->shared_from_this());
    }

    template <typename T>
    void IndexOperation<T>::backward(Matrix<T> grad)
    {
        // forward is a same-shape, zero-filled selection => d/dx = grad (.) mask
        if (grad.get_size() != this->mask.get_size())
            throw std::invalid_argument("IndexOperation::backward: gradient size does not match mask");
        Matrix<T> t1_grad = grad * this->mask;
        this->t1->accumulate(t1_grad);
    }

    template <typename T>
    void IndexOperation<T>::zero_grad(){
        this->t1->zero_grad(); 
    }

    template <typename T>
    void IndexOperation<T>::reset_graph(){
        if (this->t1) {
            this->t1->reset_graph();
            this->t1 = nullptr; // Drop strong reference
        }
    }

#endif